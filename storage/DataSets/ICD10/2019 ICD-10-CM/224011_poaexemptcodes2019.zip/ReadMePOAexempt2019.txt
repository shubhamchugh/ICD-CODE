Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2019 (36,935 codes).
POAexemptCodes2019.xlsx (Excel spreadsheet)
POAexemptCodes2019.txt (tab delimited text)
These files have three fields, as below.
Order2019: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2019.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2019 POA exempt list, from the previous list, to properly match the guidelines (63 codes).
POAexemptAddCodes2019.xlsx (Excel spreadsheet)
POAexemptAddCodes2019.txt (tab delimited text)
These files have three fields, as below.
Order2019: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2019.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2019 POA exempt list (6 codes).
POAexemptDeleteCodes2019.xlsx (Excel spreadsheet)
POAexemptDeleteCodes2019.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2019 POA exempt list (74 codes, each twice as Revise from and Revise to, for 148 lines).
POAexemptReviseCodes2019.xlsx (Excel spreadsheet)
POAexemptReviseCodes2019.txt (tab delimited text)
These files have four fields, as below.
Order2019: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2019.
Action: "Revise from" and "Revise to" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
