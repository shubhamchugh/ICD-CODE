Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2020 (37,075 codes).
POAexemptCodes2020.xlsx (Excel spreadsheet)
POAexemptCodes2020.txt (tab delimited text)
These files have three fields, as below.
Order2020: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2020.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2020 POA exempt list, from the previous list, to properly match the guidelines (152 codes).
POAexemptAddCodes2020.xlsx (Excel spreadsheet)
POAexemptAddCodes2020.txt (tab delimited text)
These files have three fields, as below.
Order2020: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2020.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2020 POA exempt list (12 codes).
POAexemptDeleteCodes2020.xlsx (Excel spreadsheet)
POAexemptDeleteCodes2020.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2020 POA exempt list (11 codes, each twice as Revise from and Revise to, for 22 lines).
POAexemptReviseCodes2020.xlsx (Excel spreadsheet)
POAexemptReviseCodes2020.txt (tab delimited text)
These files have four fields, as below.
Order2020: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2019.
Action: "Revise from" and "Revise to" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
